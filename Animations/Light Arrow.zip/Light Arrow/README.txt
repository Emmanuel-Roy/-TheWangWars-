Light Arrow Animation by Fire Blazer/Keriku

Must have permission and give credit to use!

Sprites from Fire Emblem: Blazing Sword

Insert using FEditor Adv by Zeld/Xeld/Hextator.

Contact at http://forums.feshrine.net

E-mail: smashfire17@gmail.com
AIM: fireblazerx17
MSN: blazer@feshrine.net (not used often)